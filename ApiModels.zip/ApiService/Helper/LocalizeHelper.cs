﻿using System;
using System.Reflection;
using System.Resources;

namespace ArtifiWebServices
{
    public class LocalizeHelper
    {
        #region Private Functions

        //Find Global Assembly
        private static Assembly FindGlobalResAssembly()
        {
            foreach (Assembly asm in AppDomain.CurrentDomain.GetAssemblies())
            {
                if (asm.FullName.StartsWith("ApiService"))
                    return asm;
            }
            return null;
        }

        //Find Localized Resource Value
        private static string FindLocalizedResourceValue(string ResourceName, string ResourceKey)
        {
            Assembly asm = FindGlobalResAssembly();
            if (asm == null)
                return null;
            string resourceName = string.Format("{0}.{1}.{2}", "ApiService", "Resources", ResourceName);
            return Convert.ToString(new ResourceManager(resourceName, asm).GetObject(ResourceKey));
        }

        #endregion

        #region Public Functions


        //Get Localized Message by Providing Resource Name and Resource Key
        public static string GetLocalizedString(string ResourceName, string ResourceKey)
        {
            return FindLocalizedResourceValue(ResourceName, ResourceKey);
        }

        #endregion
    }
}
