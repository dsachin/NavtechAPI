﻿using System;

namespace ArtifiWebServices
{
    public partial class WebApiResourceFile
    {
        public const String RWebApiResult = "RWebApiResult";
        public const String RWebApiValidationMsg = "RWebApiValidationMsg";
    }

    public partial class ResultResources
    {
        public const String Error = "Error";
        public const String Success = "Success";
        public const String Warning = "Warning";
    }

    public partial class ValidationResourceKey
    {
        public const String CommonError = "CommonError";
        public const String InvalidCustomerId = "InvalidCustomerId";
        public const String InvalidProductId = "InvalidProductId";
        public const String OutofStock = "OutofStock";
        public const String InvalidPayement = "InvalidPayement";
        public const String InvalidOrderStatus = "InvalidOrderStatus";
    }

    public partial class LocalResource
    {
        public static string GetLocalResult(string resourceKey)
        {
            return LocalizeHelper.GetLocalizedString(WebApiResourceFile.RWebApiResult, resourceKey);
        }
        public static string GetValidationResultMessages(string resourceKey)
        {
            return LocalizeHelper.GetLocalizedString(WebApiResourceFile.RWebApiValidationMsg, resourceKey);
        }
    }
}
