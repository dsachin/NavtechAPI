﻿using ApiService.Service.Base;

using ArtifiWebServices;

using Navtech.Models;

using System;
using System.Linq;

namespace ApiService.Service
{
    public class BaseService : IBaseService
    {
        public ApiResultModel<dynamic> PrepareReturnResult(string message, string errorCode = null, bool isSuccess = false)
        {
            ApiResultModel<dynamic> apiResult = new ApiResultModel<dynamic>();

            if (!string.IsNullOrEmpty(message))
            {
                if (isSuccess)
                {
                    apiResult.Response = LocalResource.GetLocalResult(ResultResources.Success);
                }
                else
                {
                    apiResult.ErrorCode = string.IsNullOrEmpty(errorCode)? "250":errorCode;
                    apiResult.Response = LocalResource.GetLocalResult(ResultResources.Error);
                }
                apiResult.Message = message;
            }
            else if (!string.IsNullOrEmpty(errorCode))
            {
                int[] errorCodes = errorCode.Split(',').Select(Int32.Parse).ToArray();
                apiResult.Response = LocalResource.GetLocalResult(ResultResources.Error);
                // apiResult.Message = ErrorCodeMessage.GetErrorMessage(errorCodes);
                apiResult.ErrorCode = errorCode;
                return apiResult;
            }
            else
            {
                apiResult.Response = LocalResource.GetLocalResult(ResultResources.Success);
            }

            return apiResult;
        }

    }
}
