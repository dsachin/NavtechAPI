﻿CREATE USER [test] FOR LOGIN [test]
    WITH DEFAULT_SCHEMA = [db_securityadmin];

