﻿
using ArtifiWebServices;

using Navtech.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Dependencies;

namespace Navtech.Controllers
{
    public class BaseAPIController : ApiController
    {
        public ApiResultModel<dynamic> PrepareReturnResult(string message, string errorCode = null)
        {
            ApiResultModel<dynamic> apiResult = new ApiResultModel<dynamic>();

            if (!string.IsNullOrEmpty(message))
            {
                apiResult.ErrorCode = "250";
                apiResult.Response = LocalResource.GetLocalResult(ResultResources.Error);
                apiResult.Message = message;
            }
            else if (!string.IsNullOrEmpty(errorCode))
            {
                int[] errorCodes = errorCode.Split(',').Select(Int32.Parse).ToArray();
                apiResult.Response = LocalResource.GetLocalResult(ResultResources.Error);
                // apiResult.Message = ErrorCodeMessage.GetErrorMessage(errorCodes);
                apiResult.ErrorCode = errorCode;
                return apiResult;
            }
            else
            {
                apiResult.Response = LocalResource.GetLocalResult(ResultResources.Success);
            }

            return apiResult;
        }



        ///// <summary>
        ///// This method is used to check if the Error code exits and set message if error exits.
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="apiResultModel"></param>
        //public void CheckErrorMessage<T>(ApiResultModel<IEnumerable<T>> apiResultModel)
        //{
        //    if (!string.IsNullOrEmpty(apiResultModel.ErrorCode))
        //    {
        //        int[] errorCodes = apiResultModel.ErrorCode.Split(',').Select(Int32.Parse).ToArray();
        //        apiResultModel.Message = ErrorCodeMessage.GetErrorMessage(errorCodes);
        //    }
        //}
        ///// <summary>
        ///// This method is used to check if the Error code exits and set message if error exits.
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="apiResultModel"></param>
        //public void CheckErrorMessage<T>(ApiResultModel<T> apiResultModel)
        //{
        //    if (!string.IsNullOrEmpty(apiResultModel.ErrorCode))
        //    {
        //        int[] errorCodes = apiResultModel.ErrorCode.Split(',').Select(Int32.Parse).ToArray();
        //        apiResultModel.Message = ErrorCodeMessage.GetErrorMessage(errorCodes);
        //    }
        //}
        //#region Resourses

        ///// <summary>
        ///// Get Resource Strings
        ///// </summary>
        ///// <param name="resourceName"></param>
        ///// <param name="resourceKey"></param>

        //protected virtual string Resource(string resourceName, string resourceKey)
        //{
        //    return LocalizeHelper.GetLocalizedString(resourceName, resourceKey);
        //}

        ///// <summary>
        ///// GetValidationMessage 
        ///// </summary>
        ///// <returns>Validation Message</returns>

        //protected virtual string GetValidationMessage(int errorCode)
        //{
        //    return string.Empty;
        //}

        //private string GetLocalizedError(string resourceKey)
        //{
        //    return LocalizeHelper.GetLocalizedString(FrontResourceFile.RResultMessages, resourceKey);
        //}
        //#endregion


        #region Register Dependency Injection

        //private Dictionary<Type, object> objDict = new Dictionary<Type, object>();


        //protected IDependencyResolver GetDependencyResolver()
        //{
        //    return GlobalConfiguration.Configuration.DependencyResolver;
        //}


        //protected T GetService<T>() where T : class
        //{
        //    return (T)GetDependencyResolver().GetService(typeof(T));
        //}


        #endregion
    }
}
