﻿<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>API Documentation</title>
</head>
<body>
Navigate to ~/apiDocs/apiDocs.html for documentation

Please execute data script to initilize tables with default values.
</body>
</html>